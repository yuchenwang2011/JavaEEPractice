package factory;

import java.util.List;

import entity.Item;
import entity.Order;

public class OrderFactory {
	public OrderFactory() {}
	public static Order getOrder(List<Item> items) {
		return new Order(items);
	}
}
