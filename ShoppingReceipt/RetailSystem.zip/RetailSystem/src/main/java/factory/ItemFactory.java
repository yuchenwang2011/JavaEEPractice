package factory;

import java.util.ArrayList;
import java.util.List;

import entity.Item;

public class ItemFactory{
	public ItemFactory() {}
	public static List<Item> getAllItems(List<String> itemsInfo){
		List<Item> items = new ArrayList<Item>();
		if(itemsInfo.size() == 0) {
			return items;
		}

		for(String s : itemsInfo) {
			String[] info = s.split(",");
			
			Long id = Long.valueOf(info[0]);
			String name = info[1];
			double price = Double.valueOf(info[2]);
			boolean isImported = Boolean.valueOf(info[3]);
			boolean taxable = Boolean.valueOf(info[4]);
			String measureWord = info[5];
			boolean bulk = Boolean.valueOf(info[6]);
			int amount = Integer.valueOf(info[7]);
			
			Item item = new Item(id, name, price, isImported, taxable, measureWord, bulk, amount);
			items.add(item);
		}
		
		return items;
	}
}