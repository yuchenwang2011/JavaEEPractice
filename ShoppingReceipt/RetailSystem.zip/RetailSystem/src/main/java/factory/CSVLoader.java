package factory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class CSVLoader {
	public static List<String> load(String DATAPath){
		List<String> itemInfo = new ArrayList<String>();
	    BufferedReader reader = null;
	    String line = "";
	    try{
	      reader = new BufferedReader(new FileReader(DATAPath));
	      
	      //Remove the first line
	      line = reader.readLine();
	      while( (line =  reader.readLine()) != null) {
	    	  	itemInfo.add(line);
	      }
	    } catch (Exception e) {
	    		e.printStackTrace();
	        System.out.println("Fail to load CSV file");
		}
		return itemInfo;
	}
}
