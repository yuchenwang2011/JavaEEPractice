package factory;

import entity.Order;
import entity.Receipt;

public class ReceiptFactory {
	public ReceiptFactory() {}
	public static Receipt getReceipt(Order order) {
		return new Receipt(order);
	}
}
