package main;

import java.util.List;

import entity.Item;
import entity.Order;
import entity.Receipt;
import factory.CSVLoader;
import factory.ItemFactory;
import factory.OrderFactory;

public class Main {
	public static void main(String[] args) {
		String DATAPATH = "src/main/resources/InputData.csv";
		List<String> itemsInfo = CSVLoader.load(DATAPATH);
		List<Item> items = ItemFactory.getAllItems(itemsInfo);
		Order order = OrderFactory.getOrder(items);
		Receipt receipt = new Receipt(order);
		receipt.printReceipt();
	}
}
