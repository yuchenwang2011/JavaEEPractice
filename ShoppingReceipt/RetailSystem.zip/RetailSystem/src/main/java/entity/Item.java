package entity;

public class Item {
	private long id;
	private String name;
	private double price;
	private boolean isImported;
	private boolean taxable;
	private String measureWord;
	private boolean bulk;
	private int amount;
	
	public Item(long id, String name, double price, boolean isImported, boolean taxable,
			String measureWord, boolean bulk, int amount) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.isImported = isImported;
		this.taxable = taxable;
		this.measureWord = measureWord;
		this.bulk = bulk;
		this.amount = amount;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public boolean isImported() {
		return isImported;
	}
	public void setImported(boolean isImported) {
		this.isImported = isImported;
	}
	public boolean isTaxable() {
		return taxable;
	}
	public void setTaxable(boolean taxable) {
		this.taxable = taxable;
	}
	public String getMeasureWord() {
		return measureWord;
	}
	public void setMeasureWord(String measureWord) {
		this.measureWord = measureWord;
	}
	public boolean isBulk() {
		return bulk;
	}
	public void setBulk(boolean bulk) {
		this.bulk = bulk;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Item [id=" + id + ", name=" + name + ", price=" + price + ", isImported=" + isImported + ", taxable="
				+ taxable + ", measureWord=" + measureWord + ", bulk=" + bulk + ", amount=" + amount + "]";
	}
}
