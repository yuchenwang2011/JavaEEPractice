package entity;

import java.util.ArrayList;
import java.util.List;

public class Receipt {
	private Order order;
	private static final double TAX_RATE = 0.1;
	private static final double PRECISION = 0.05;
	
	private double beforeTaxTotal;
	private double importDuty;
	private double generalTax;
	private double totalTax;
	private double total;
	
	private List<String> result;
	
	public Receipt(Order order) {
		this.setOrder(order);
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	
	public List<String> checkOut(){
		List<String> result = new ArrayList<String>();
		
		double importDuty = 0;
		double generalTax = 0;
		double sum = 0;
		for(Item item: order.getItems()) {
			String measureWord = item.getMeasureWord() 
					+ (item.getAmount() > 1 && item.getMeasureWord().length() > 0 ? "s" : "") 
					+ (item.getMeasureWord().length() > 0 ? " of " : "");
			
 			String s = item.getAmount() + " "
					+ (item.isImported() ? "imported " : "")
					+ measureWord
					+ item.getName() + (item.isBulk() ? "s" : "")
					+ ": " + item.getPrice();
			result.add(s);
			sum += item.getPrice() * item.getAmount();
			importDuty += item.isImported() ? item.getPrice() : 0;
			generalTax += item.isTaxable() ? item.getPrice() * TAX_RATE : 0; 
		}
		sum = Receipt.roundDouble(sum, PRECISION);
		this.setBeforeTaxTotal(sum);
		result.add("Before tax total: " + sum);
		
		importDuty = Receipt.roundDouble(importDuty, PRECISION);
		this.setImportDuty(importDuty);
		result.add("Import duty: " + importDuty);
		
		generalTax = Receipt.roundDouble(generalTax, PRECISION);
		this.setGeneralTax(generalTax);
		result.add("General tax: " + generalTax);
		
		double totalTax = importDuty + generalTax;
		this.setTotalTax(totalTax);
		result.add("Sales Taxes total: " + totalTax);
		
		sum = sum + totalTax;
		this.setTotal(sum);
		result.add("Total: " + sum);
		
		this.setResult(result);
		return result;
	}
	
	public static double roundDouble(double d, double precisition) {
		int i = (int) (1 / precisition);
	    return Math.round(d * i) / (double) i;
	}
	
	public void printReceipt() {
		List<String> result = checkOut();
		for(String s : result) {
			System.out.println(s);
		}
	}
	public double getBeforeTaxTotal() {
		return beforeTaxTotal;
	}
	public void setBeforeTaxTotal(double beforeTaxTotal) {
		this.beforeTaxTotal = beforeTaxTotal;
	}
	public double getImportDuty() {
		return importDuty;
	}
	public void setImportDuty(double importDuty) {
		this.importDuty = importDuty;
	}
	public double getGeneralTax() {
		return generalTax;
	}
	public void setGeneralTax(double generalTax) {
		this.generalTax = generalTax;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public static double getTaxRate() {
		return TAX_RATE;
	}
	public static double getPrecision() {
		return PRECISION;
	}
	public double getTotalTax() {
		return totalTax;
	}
	public void setTotalTax(double totalTax) {
		this.totalTax = totalTax;
	}
	public List<String> getResult() {
		return result;
	}
	public void setResult(List<String> result) {
		this.result = result;
	}
}
