import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import entity.Item;
import entity.Order;
import entity.Receipt;
import factory.CSVLoader;
import factory.ItemFactory;
import factory.OrderFactory;
import factory.ReceiptFactory;

public class SystemTest {
	private static final String DATAPATH = "src/main/resources/InputData.csv";
	
	
    //Test CSVLoader
    @Test()
    public void testReadFileNotFound() {
    		List<String> itemsInfo = CSVLoader.load(DATAPATH + "wrong_path");
    		Assert.assertEquals(0, itemsInfo.size());
    		System.out.println("This is expected for unit test");
    }
	
    //Test CSVLoader 
	@Test
	public void testReadFileContentColumnNumber() {
		List<String> itemsInfo = CSVLoader.load(DATAPATH);
		if(itemsInfo.size() > 0) {
			int columnNumber = itemsInfo.get(0).split(",").length;
			//The correct input file should have 8 attributes (columns)
			Assert.assertEquals(8, columnNumber);
		}
	}
	
	//Test ItemFactory
	@Test
	public void testItemFactoryEmptyInput() {
		List<String> emptyList = new ArrayList<String>();
		List<Item> items = ItemFactory.getAllItems(emptyList);
		Assert.assertEquals(0, items.size());
	}
	
	//Test ItemFactory
	@Test
	public void testItemFactoryGeneratedItem() {
		List<String> itemsInfo = CSVLoader.load(DATAPATH);
		List<Item> items = ItemFactory.getAllItems(itemsInfo);
		if(items.size() != 0) {
			Assert.assertEquals(items.get(0).getName(), (itemsInfo.get(0).split(","))[1]);
		}
	}
	
	//Test OrderFactory
	@Test
	public void testOrderFactoryEmptyInput() {
		List<Item> items = new ArrayList<Item>();
		Order order = OrderFactory.getOrder(items);
		Assert.assertEquals(0, order.getItems().size());
	}
	
	//Test OrderFactory
	@Test
	public void testOrderFactoryGeneratedOrder() {
		List<String> itemsInfo = CSVLoader.load(DATAPATH);
		List<Item> items = ItemFactory.getAllItems(itemsInfo);
		Order order = OrderFactory.getOrder(items);
		Assert.assertEquals(order.getItems().size(), itemsInfo.size());
		Assert.assertEquals(order.getItems().size(), items.size());
	}
	
	//Test ReceiptFactory
	@Test
	public void testReceiptFactoryEmptyInput() {
		List<Item> items = new ArrayList<Item>();
		Order order = OrderFactory.getOrder(items);
		Receipt receipt = ReceiptFactory.getReceipt(order);
		Assert.assertEquals(0, receipt.getOrder().getItems().size());
	}
	
	//Test ReceiptFactory
	@Test
	public void testReceiptFactoryGeneratedReceipt() {
		List<String> itemsInfo = CSVLoader.load(DATAPATH);
		List<Item> items = ItemFactory.getAllItems(itemsInfo);
		Receipt receipt = ReceiptFactory.getReceipt(OrderFactory.getOrder(items));
		Assert.assertEquals(receipt.getOrder().getItems().size(), itemsInfo.size());
	}
	
	//Test ReceiptFactory
	@Test
	public void testReceiptRounding() {
		Assert.assertEquals(4.00d, Receipt.roundDouble(3.99d, 0.05), 0.01);
		Assert.assertEquals(3.95d, Receipt.roundDouble(3.932, 0.05), 0.01);
		Assert.assertEquals(3.90d, Receipt.roundDouble(3.922, 0.05), 0.01);
	}
	
	//Test ReceiptFactory
	@Test
	public void testReceiptImportedDuty() {
		Item importItem1 = new Item(1, "Perfume", 33.5d, true, true, "bottle", false, 1);
		Item importItem2 = new Item(2, "Laptop", 399.99d, true, true, "box", false, 1);
		Item localItem3 = new Item(3, "milk", 4.55d, false, false, "bag", false, 1);
		List<Item> items = new ArrayList<Item>();
		items.add(importItem1);
		items.add(importItem2);
		items.add(localItem3);
		Receipt receipt = ReceiptFactory.getReceipt(OrderFactory.getOrder(items));
		receipt.checkOut();
		double actualDuty = 33.5d + 399.99d;
		Assert.assertEquals(actualDuty,receipt.getImportDuty(), 0.01);
	}
	
	//Test ReceiptFactory
	@Test
	public void testReceiptGeneralTax() {
		Item importItem1 = new Item(1, "Perfume", 33.5d, true, true, "bottle", false, 1);
		Item importItem2 = new Item(2, "Laptop", 399.99d, true, true, "box", false, 1);
		Item localItem3 = new Item(3, "milk", 4.55d, false, false, "bag", false, 1);
		Item localItem4 = new Item(4, "chocolate", 15.49, false, true, "box", true, 1);
		List<Item> items = new ArrayList<Item>();
		items.add(importItem1);
		items.add(importItem2);
		items.add(localItem3);
		items.add(localItem4);
		Receipt receipt = ReceiptFactory.getReceipt(OrderFactory.getOrder(items));
		receipt.checkOut();
		double actualDuty = (33.5d + 399.99d + 15.49) * 0.1;
		Assert.assertEquals(actualDuty,receipt.getGeneralTax(), 0.01);
	}
	
	//Test ReceiptFactory
	@Test
	public void testReceiptTotalTax() {
		Item importItem1 = new Item(1, "Perfume", 33.5d, true, true, "bottle", false, 1);
		Item importItem2 = new Item(2, "Laptop", 399.99d, true, true, "box", false, 1);
		Item localItem3 = new Item(3, "milk", 4.55d, false, false, "bag", false, 1);
		Item localItem4 = new Item(4, "chocolate", 15.49, false, true, "box", true, 1);
		List<Item> items = new ArrayList<Item>();
		items.add(importItem1);
		items.add(importItem2);
		items.add(localItem3);
		items.add(localItem4);
		Receipt receipt = ReceiptFactory.getReceipt(OrderFactory.getOrder(items));
		receipt.checkOut();
		double totalTax = (33.5d + 399.99d + 15.49) * 0.1 + (33.5d + 399.99d);
		totalTax = Receipt.roundDouble(totalTax, 0.05);
		Assert.assertEquals(totalTax,receipt.getTotalTax(), 0.01);
	}
	
	//Test ReceiptFactory
	@Test
	public void testReceiptTotal() {
		Item importItem1 = new Item(1, "Perfume", 33.5d, true, true, "bottle", false, 1);
		Item importItem2 = new Item(2, "Laptop", 399.99d, true, true, "box", false, 1);
		Item localItem3 = new Item(3, "milk", 4.55d, false, false, "bag", false, 1);
		Item localItem4 = new Item(4, "chocolate", 15.49, false, true, "box", true, 1);
		List<Item> items = new ArrayList<Item>();
		items.add(importItem1);
		items.add(importItem2);
		items.add(localItem3);
		items.add(localItem4);
		Receipt receipt = ReceiptFactory.getReceipt(OrderFactory.getOrder(items));
		receipt.checkOut();
		double totalTax = (33.5d + 399.99d + 15.49) * 0.1 + (33.5d + 399.99d);
		totalTax = Receipt.roundDouble(totalTax, 0.05);
		
		double total = totalTax + Receipt.roundDouble((33.5d + 399.99d + 4.55d + 15.49d), 0.05);
		Assert.assertEquals(total,receipt.getTotal(), 0.01);
	}
	
	//Test ReceiptFactory
	@Test
	public void testReceiptPrint() {
		Item importItem1 = new Item(1, "Perfume", 33.5d, true, true, "bottle", false, 1);
		Item importItem2 = new Item(2, "Laptop", 399.99d, true, true, "box", false, 1);
		Item localItem3 = new Item(3, "milk", 4.55d, false, false, "bag", false, 1);
		Item localItem4 = new Item(4, "chocolate", 15.49, false, true, "box", true, 1);
		List<Item> items = new ArrayList<Item>();
		items.add(importItem1);
		items.add(importItem2);
		items.add(localItem3);
		items.add(localItem4);
		Receipt receipt = ReceiptFactory.getReceipt(OrderFactory.getOrder(items));
		receipt.checkOut();
		
		//The final result should have 5 more summary rows than items
		int summaryRows = receipt.getResult().size();
		Assert.assertEquals(summaryRows, items.size() + 5);
		List<String> result = receipt.getResult();
		Assert.assertTrue(result.get(result.size() - 1).contains("Total: "));
		Assert.assertTrue(result.get(result.size() - 2).contains("Sales Taxes"));
	}
}
